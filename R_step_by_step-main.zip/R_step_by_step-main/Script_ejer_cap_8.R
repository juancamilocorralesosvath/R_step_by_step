# Los archivos con extensión .txt pueden 
# ser leídos empleando la función read.table()
# por ejemplo: 
# leyendo el archivo .txt 
# primero la ruta del archivo entre comillas, header si la informacion tiene encabezados
# sep la manera en como están separados los datos. 
# employee <- read.table("employee.txt", header = TRUE, sep = ",")
# verificando la clase del objeto
# class(employee)
# 
# inspeccionando los primeros 5 datos 
# head(employee, 5)
# inspeccionando los últimos 3 datos 
# tail(employee, 2)
# inspeccionando la clase de cada variable 
# str(employee)
# leyendo el archivo .csv
# employee2 <- read.csv("employee.csv", header = TRUE, sep = ";")
# verificando la clase del objeto
# class(employee2)


# para importar datos desde un excel:
#instalar el paquete si no lo tienes aún instalado
#install.packages("readxl")
# cargando el paquete
# library(readxl)
# leyendo datos del archivo .xlsx que está en hoja2 
# la diferencia es que con la funcion read_excel podemos especificar
# la hoja en la que se encuentra la informacion asi como el rango.
# employee3 <- read_excel("employee.xlsx", sheet = 2, 
#                        range = "C2:E62")
# verificando la clase del objeto
# class(employee3)
# a ver, hagamos el ejemplito:

#install.packages("gapminder")
library(gapminder)
data(package = "gapminder")
help(gapminder)

#y de esta manera cargamos lo que queremos al working space
data("gapminder")
class(gapminder)
help(read.csv)

spotify <- read.csv("spotify_dataset.csv", header = TRUE, sep = ",")

class(spotify)

str(spotify)


#spotify$Streams <- as.integer(gsub(",", "", spotify$Streams))


str(spotify)

# cargando las peliculas:
movies_shows <- read.table("ejercicio_modulo3.txt", header = TRUE, sep = ",")
class(movies_shows)
str(movies_shows)

# resulta que estas variables debian ser de tipo factor. No tengo claro el por qué.
movies_shows$Netflix <- as.factor(movies_shows$Netflix)
movies_shows$Hulu <- as.factor(movies_shows$Hulu)
movies_shows$Prime.Video <- as.factor(movies_shows$Prime.Video)
movies_shows$Disney. <- as.factor(movies_shows$Disney.)
movies_shows$Type <- as.factor(movies_shows$Type)
# y este por que numeric?
movies_shows$Rotten.Tomatoes <- as.numeric(gsub("/100", "", movies_shows$Rotten.Tomatoes))

str(movies_shows)
# escribirle al monitor: ¿por qué en este caso se trataba de factors?

preguntasMod3 <- read.csv("archivo_datos.csv", header=TRUE, sep = ",")

class(preguntasMod3)

str(preguntasMod3)


examencito <- read.csv("archivo4.csv", header=TRUE, sep = ",")
class(examencito)
install.packages("MASS")
library(MASS)
data(package = "MASS")
str(Boston)
str(Animals)
# guardar el workspace:
#save.image(file = "Ws_ejer_cap_8.RData")
