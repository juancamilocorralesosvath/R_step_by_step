load(file = "Ws_ejer_cap_8.RData")
rm(spotify)
class(movies_shows)
str(movies_shows)
movies <- movies_shows$Title
str(movies)

# guardar el workspace:
save.image(file = "Ws_dplyr_C2.RData")
# Crea el objeto movies que solo contenga 
# los datos de las películas. ¿Cuántas películas tenemos?
# intalar dplyr
install.packages("dplyr")
# Cargando paquete
library(dplyr)
# Carga de bases de datos
movies <- filter(movies_shows, Type == 0)
movies
# nota que tenemos 9515 películas
print("numero de películas que tenemos: ")
print(9404+111)

#Ahora mira cuenta cuántas películas tenemos 
# en la plataforma de Netflix por año. Y ordena el 
# resultado para que aparezca primero el último año disponible.
movies %>% 
  filter(Netflix == 1) %>% 
  group_by(Year) %>% 
  summarise(Numero = n()) %>% 
  arrange(desc(Year))
# uy ojo aqui: tenemos que revisar que hace cada operacion.

# Otra forma de hacer lo mismo
#movies %>% 
#   filter(Netflix == 1) %>% 
#   count(desc(Year))

# Ahora concentrémonos en los años 2018, 2019 y 2020. 
# Ahora calcula la calificación promedio (en Rotten Tomatoes) 
# por año para las películas que están en la plataforma de Netflix. 
# Ten cuidado que debes descartar aquellas observaciones que no tenga 
# datos para la calificación de Rotten Tomatoes.
movies %>% 
  filter(Year >= 2018 & Year <= 2020) %>% 
  filter(Netflix == 1) %>% 
  filter( !is.na(Rotten.Tomatoes)) %>%
  group_by(Year) %>%
  summarise(Cal_Netflix = mean(Rotten.Tomatoes))
# por qué no me está mostrando los números?

# Ahora realice el mismo cálculo pero para la plataforma Prime Video

movies %>% 
  filter(Year >= 2018 & Year <= 2020) %>% 
  filter(Prime.Video == 1) %>% 
  filter( !is.na(Rotten.Tomatoes)) %>%
  group_by(Year) %>%
  summarise(Cal_Prime = mean(Rotten.Tomatoes))

save.image(file = "Ws_dplyr_C2.RData")


# Carga de bases de datos
spotify <- read.csv("spotify_dataset.csv",
                    header = TRUE, sep = ",")
# mirar la clase del objeto
class(spotify)
# cambiando a clase tibble
library(dplyr)

spotify <- as_tibble(spotify)
glimpse(spotify)


spotify %>% 
  select(Song.Name, Genre, Streams) %>% 
  glimpse()

#construir una base que tenga solo las variables 
#Song.Name y Streams, pero 
#sólo de aquellas canciones que pertenecen al género pop
spotify_pop <- spotify %>% 
  filter(Genre == "['pop']") %>% 
  select(Song.Name, Streams)

# mirando los resultados
glimpse(spotify_pop)
# contains() que permite seleccionar todas las 
# variables que contengan uno o varios carácteres deseados. 
spotify_punto <- select(spotify, contains("."))
# mirando los resultados
glimpse(spotify_punto)
# escoger un rango de variables que estén adyacentes.
spotify %>% 
  select(Acousticness:Valence) %>% 
  glimpse()
#queremos excluir las variables
#que están entre Song.Name y Chord en el objeto original
spotify_red <- select(spotify, !Song.Name:Chord)

# mirando los resultados
glimpse(spotify_red)
# El mismo resultado se logra con el siguiente código:
spotify_red <- select(spotify, -c(Song.Name:Chord))

#mutate() . El primer argumento de esta función es el 
#objeto con los datos y los restantes corresponden a 
#las nueva variables que se quieran crear. Las nuevas 
#variables se especifican 
#con su nuevo nombre y la operación que se desea realizar.

# queremos conocer cuántas reproducciones 
#tiene cada canción por seguidor del artista 
#principal en Spotify. Es decir, 
#la división de la variable Streams por Artist.Followers
spotify %>% 
  mutate(Rep_follow = Streams / Artist.Followers) %>%
  glimpse()
# sale error...

# El verbo rename() permite cambiar el nombre de una o más variables. 

spotify_rename <- rename(spotify, 
                         Artist_Followers = Artist.Followers)
# mirando solo los nombres de las variables
names(spotify_rename)
# rename_with() -> automatizar cambios de muchas variables a la vez

spotify_upper1 <- rename_with(spotify, toupper)
# mirando solo los nombres de las variables
#toupper() para pasar todos los nombres de 
#las variables a solo mayúsculas (en inglés upper case).
names(spotify_upper1)
#JUGANDO con varias funciones
spotify_upper2 <- rename_with(spotify, toupper, contains("."))
# mirando solo los nombres de las variables
names(spotify_upper2)
#Nota que solo pasamos a mayúsculas las 
#variables cuyos nombres contienen un 
#punto (.). Ahora puedes intentar con diferentes opciones

# consideremos el verbo transmute() , 
#este es una combinación de los verbos select() y mutate().

spotify_t <- transmute(spotify, Song.Name, 
                       Genre, Streams, 
                       Rep_follow = Streams / Artist.Followers)

# mirando solo los nombres de las variables
names(spotify_t)

# EJERCICIO # 2 MÓDULO 4
# Carga de bases de datos
movies_netflix <- movies %>% 
  filter(Netflix == 1) %>% 
  select("Title", "Year", "Age", "Rotten.Tomatoes")

#Ahora crea en el objeto movies_netflix 
#una nueva variable que se llame Plataforma. 
#Esta variable será igual a “Netflix” 
#para todos los casos de este objeto.
movies_netflix <- movies_netflix  %>% 
  mutate(Plataforma = "Netflix")

#A continuación, crea un objeto con el nombre 
  #movies_prime que tenga las mismas variables 
  #que finalmente tiene el objeto movies_netflix. 
  #La única diferencia es que el objeto movies_prime 
  #tiene solo las películas de Prime.Video y la 
  #variable Plataforma será igual a “Prime Video”.  
movies_prime <- movies %>% 
  filter(Prime.Video == 1) %>% 
  select("Title", "Year", "Age",
         "Rotten.Tomatoes")  %>% 
  mutate(Plataforma = "Prime Video")

#Ahora repite el mismo procedimiento para 
#crear el objeto movies_disney. La variable
#Plataforma será igual a “Disney Plus”.

movies_disney <- movies %>% 
  filter(Disney. == 1) %>% 
  select("Title", "Year", "Age",
         "Rotten.Tomatoes")  %>% 
  mutate(Plataforma = "Disney Plus")

# preguntas de chequeo

class(gapminder)
# cambiando el objeto data frame gapminder a clase tibble
gapminder <- as_tibble(gapminder)
glimpse(gapminder)

PIB <- gapminder %>% 
  filter(year == 2007) %>% 
  filter(country == "Colombia")
  
PIB <- PIB %>% 
  mutate(result = (gdpPercap * pop)/1000000 )
PIB  
# LAUDETUR IESUS CHRISTUS

# CAPÍTULOS 4 Y 5

# Carga de bases de datos
obj1 <- read.csv("obj1.csv", header = TRUE, sep = ",")
obj2 <- read.csv("obj2.csv", header = TRUE, sep = ",")
# Mirando los objetos
obj1
obj2
#Ahora, para combinar los dos objetos en uno solo, 
#usaremos el verbo bind_rows() empleando los 
#dos objetos como argumentos.

obj3 <- bind_rows(obj1, obj2)

obj3
#la función bind_rows() al requerir menos memoria RAM, es mas rápida que la 
# que viene por default con R (rbind()).
#Esto permite agilizar el análisis, en especial si 
#tenemos muchos datos o estamos empleando Big Data. 
#Y por otro lado, la función bind_rows() permite combinar 
#dos objetos de clase data.frame que tengan diferente 
#número de columnas. rbind() presentará un error, mientras que bind_rows() 
#asigna “NA” a aquellas filas de las columnas que faltan.

#bind_cols() --> datos para los mismos individuos en dos objetos y necesitamos fusionarlos en uno solo

# Carga de bases de datos
obj1b <- read.csv("obj1b.csv", header = TRUE, sep = ",")

# Mirando los objetos
obj1b

#En el archivo obj1b.csv20 tenemos datos para las variables D y E de los mismos individuos que están en el objeto obj1

obj4 <- bind_cols(obj1, obj1b)
obj4
#La variable ID estaba en ambos objetos y por tanto aparece dos veces en 
#el nuevo objeto creado. Para evitar esto podemos usar el verbo select(), 

obj4 <- obj1b %>% 
  select(-c(ID)) %>% 
  bind_cols(obj1)
obj4

# Carga de bases de datos
obj5 <- read.csv("obj5.csv", header = TRUE, sep = ",")

# Mirando los objetos
obj5

# resulta que tenemos casos del objeto 5 que estan en el objeto 2. pero no
# todos. 
# en este caso vamos a emplear el verbo  inner_join()
#inner_join()-->Este verbo implica retener solo los casos que están en ambos objetos




# inner join
obj6 <- inner_join(obj5, obj2, by = "ID")
# mirando el objeto
obj6

# otras maneras: left & right join:
# left join
obj7 <- left_join(obj5, obj2, by = "ID")
# mirando el objeto
obj7

# right join
obj8 <- right_join(obj5, obj2, by = "ID")
# mirando el objeto
obj8

# nota: si nos surgen dudas, podemos darle una revisada al 
# capitulo 4 de nuevo para ver las imagenes en donde explican los procesos.
# full join
obj9 <- full_join(obj5, obj2, by = "ID")
# mirando el objeto
obj9
# otras funciones de ayuda: intersect(), union(), semi_join() y anti_join().

# segunda ronda de ejercicios
#Crea un objeto para solo las películas de la plataforma Hulu 
#(recuerda crear la variable Plataforma). Ahora, unamos los cuatro 
#objetos movies_netflix, movies_prime, movies_disney y movies_hulu
#ara crear el objeto movies2.
movies_hulu <- movies %>% 
  filter(Hulu == 1) %>% 
  select("Title", "Year", "Age",
         "Rotten.Tomatoes")  %>% 
  mutate(Plataforma = "Hulu")

movies_hulu
#Nota que este nuevo objeto conforma una base de datos que tiene la misma información que el objeto movies. Pero este último objeto tiene 9 variables y movies2 solo 5. Esto ocurre porque la variable Type no es relevante, al tener unos datos filtrados para solo películas. Y las variables Netflix, Hulu, Prime.Video y Disney las sintetizamos en una variable que llamamos Plataforma. Dado que hay películas que aparecen en varias plataformas, tendremos mas filas en el objeto movies2 que en movies. De hecho, la forma como está presentada la base de datos movies se conoce como la forma ancha (wide) y movies2 com la forma larga (long).
# crear una solo objeto 
movies2 <- bind_rows(movies_netflix, movies_prime, movies_disney, movies_hulu)




#Ahora, calcula el promedio de las calificaciones 
#de Rotten Tomatoes para el 2019 para cada plataforma 
#empleando el objeto movies2.
#Recuerda quitar los casos que no tienen calificación.

movies2 %>%  
  filter(Year == 2019) %>% 
  filter( !is.na(Rotten.Tomatoes)) %>%
  group_by(Plataforma) %>% 
  summarise(Cal_prom = mean(Rotten.Tomatoes))

















save.image(file = "Ws_modulo4.RData")


